chrome.storage.local.get('css', function(result) {
    if (result.css) {
        var style = document.createElement('style');
        style.textContent = result.css;
        document.head.appendChild(style);
    }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action == 'appendCss') {
        var style = document.createElement('style');
        style.textContent = request.css;
        document.head.appendChild(style);
        chrome.storage.local.set({ 'css': request.css });
        sendResponse({ success: true });
    } else if (request.action == 'removeCss') {
        var style = document.querySelector('style');
        if (style) {
            style.remove();
            chrome.storage.local.remove('css');
            sendResponse({ success: true });
        } else {
            sendResponse({ success: false });
        }
    }
});
