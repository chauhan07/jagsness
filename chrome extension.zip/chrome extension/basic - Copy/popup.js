document.addEventListener('DOMContentLoaded', function() {
    var appendButton = document.getElementById('appendButton');
    var removeButton = document.getElementById('removeButton');
    var j = 0;
    appendButton.addEventListener('click', function() {
        if(j==0){
            var css = `
                body{
                    background:#000;
                }
            `;
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, { action: 'appendCss', css: css }, function(response) {
                    if (response.success) {
                        console.log('CSS appended successfully.');
                    } else {
                        console.log('Failed to append CSS.');
                    }
                });
            });
            j++;
        }
    });
    
    removeButton.addEventListener('click', function() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'removeCss' }, function(response) {
                if (response.success) {
                    console.log('CSS removed successfully.');
                } else {
                    console.log('Failed to remove CSS.');
                }
            });
        });
    });
});