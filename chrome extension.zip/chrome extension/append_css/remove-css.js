let style = document.querySelector('style');
if (style) {
  style.remove();
}
