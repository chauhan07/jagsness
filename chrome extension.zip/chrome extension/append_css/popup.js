let addCssBtn = document.getElementById('add-css-btn');
//let removeCssBtn = document.getElementById('remove-css-btn');

addCssBtn.addEventListener('click', function(){
    chrome.tabs.insertCSS({file: 'style.css'});
});
//removeCssBtn.addEventListener('click', removeCss);
//
//function addCss() {
//    alert("yes");
//  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//    chrome.tabs.insertCSS({file: 'style.css'});
//    chrome.storage.local.set({isCssAdded: true});
//  });
//}
//
//function removeCss() {
//  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//    chrome.tabs.executeScript(tabs[0].id, {file: 'remove-css.js'});
//    chrome.storage.local.set({isCssAdded: false});
//  });
//}
