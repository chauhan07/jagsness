chrome.storage.local.get(['isCssAdded'], function(result) {
  if (result.isCssAdded) {
    let css = `
      /* Your CSS goes here */
body{
background:#000
}
    `;

    let style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }
});
