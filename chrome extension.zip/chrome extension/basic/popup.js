chrome.tabs.query({
    active: true,
    currentWindow: true
}, function (tabs) {
    var url = tabs[0].url;
    document.getElementById('url').textContent = url;
    var j = 0;
    var cssButton = document.getElementById('add-css');
    var removeButton = document.getElementById('remove-css');
    cssButton.addEventListener('click', function () {
        j++;
        if (j == 1) {
            chrome.tabs.insertCSS({
                file: 'style.css'
            });
        }
        chrome.storage.local.set({
            isCssAdded: true
        });
    });
    removeButton.addEventListener('click', function () {
        j = 0;
        chrome.tabs.removeCSS({
            file: 'style.css'
        });
    });
});
