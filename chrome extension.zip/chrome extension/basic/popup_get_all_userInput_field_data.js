chrome.tabs.executeScript({
  code: "var inputs = document.querySelectorAll('input[name]');" +
        "var values = [];" +
        "for (var i = 0; i < inputs.length; i++) {" +
        "  values.push(inputs[i].name + ': ' + inputs[i].value);" +
        "}" +
        "values;"
}, function(result) {
  var inputFields = document.getElementById('input-fields');
  for (var i = 0; i < result[0].length; i++) {
    var li = document.createElement('li');
    li.innerText = result[0][i];
    inputFields.appendChild(li);
  }
});
