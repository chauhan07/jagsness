$('#homeBannerSlider').owlCarousel({
    loop: true,
    margin: 0,
    nav: false,
    autoplay: true,
    animateOut: 'slideOutUp',
    responsive: {
        0: {
            items: 1
        }
    }
})