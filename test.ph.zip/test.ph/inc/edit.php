<?php 
    if(isset($_POST['submit'])) {
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $_SESSION['logedin_user_email'] = $email; // neewd to redeclare session taaki koi error na aaye other wise user ko logout karna padega 

        // print_r($_FILES['user_image']);
        // die;

        if (isset($_FILES['user_image']) && !empty($_FILES['user_image']['name'])) {
            $file = $_FILES['user_image'];
            // Get the file name
            $userImageName = 'profile-'.rand().'-'.$file['name'];
            // Get the file tmp name
            $tmpname = $file['tmp_name'];
            // Move the uploaded file to a new location
            move_uploaded_file($tmpname, "../assets/uploads/" . $userImageName);
        }else{
            $userImageName = $ap_user_data['image_path'];
        }

        $user_id = $ap_user_data["id"];


        // SQL query to insert data
        $sql = "UPDATE userdata SET first_name='$first_name',lastName='$last_name',email='$email',phone='$phone',image_path='$userImageName' WHERE id='$user_id'";

        if ($conn->query($sql) === TRUE) {
            header('Location: ./?success');

            // use below code when you want to logout user when they change there email id
            // if($_SESSION['logedin_user_email'] === $email){
            //     header('Location: ./?success');
            // } else{
            //     // Destroy the session
            //     session_destroy();
            
            //     // Redirect to a new page
            //     header("location: ../login.php");
            // }

        } else {
            echo "Error updating record: " . $conn->error;
        }

        
    }
?>