<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="http://test.ph/assets/js/owl-carousel.js"></script>
<script src="http://test.ph/assets/js/function.js"></script>
</body>
</html>