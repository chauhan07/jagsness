<?php 

$pro_id = $_GET['product-id'];
$sql = "SELECT * FROM ap_products_data where id = '$pro_id'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // echo "<pre>";
    // print_r($row);
    // echo "</pre>";
} else {
    $product_msg = "Product Not Found";
    $className = 'alert-danger';
}

?>