<?php 
    $page_title = 'Register | PHP';
    include 'inc/header.php'; 

?>

<section class="banner-pages">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1>
                    Products
                </h1>
            </div>
        </div>
    </div>
</section>
<section class="container-fluid product-box">
    <div class="container">
        <div class="row">


        <?php 
        // Query to retrieve the latest 20 items from the table
        $sql = "SELECT * FROM ap_products_data ORDER BY id DESC LIMIT 20";

        // Execute the query
        $result = mysqli_query($conn, $sql);

        // Loop through the results and output them
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 mt-3 mb-3">
                <div class="inner">
                    <figure>
                        <?php if(!empty($row['pro_image'])){
                            $image_path = './assets/uploads/products/'.$row['pro_image'];
                        } else{
                            $image_path = './assets/images/placeholder.png';
                        }
                        ?>
                        <img src="<?php echo $image_path; ?>" alt="">
                    </figure>
                    <div class="desc">
                        <h3 class="title">
                            <?php echo $row['pro_name']; ?>
                        </h3>
                        <div class="desc_text">
                        <?php echo substr($row['pro_desc'], 0, 100); ?>...
                        </div>
                        <a href="./view-product?product-id=<?php echo $row['id']; ?>" class="buyNowBtn">
                            View Product
                        </a>
                    </div>
                </div>
            </div>
            <?php
            }
        } else {
            echo "0 results";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>


        </div>
    </div>
</section>

<?php
include 'inc/footer.php';
?>