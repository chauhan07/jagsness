<?php 
$page_title = 'Register | PHP';
include 'inc/header.php'; 
include 'inc/view_product.php'; 
?>

    <section class="banner-pages">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>
                        <?php echo $row['pro_name'];?>
                    </h1>
                </div>
            </div>
        </div>
    </section>
    <section class="container-fluid single-product">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="inner">
                        <?php 
                            if(!empty($row['pro_gallery'])){ 
                            $galleryImages = explode(",", $row['pro_gallery']);
                        ?>
                            <div class="owl-carousel owl-theme product-carousel">
                                <?php foreach($galleryImages as $item){?>
                                <div class="item">
                                    <img src="./assets/uploads/products-gallery/<?php echo trim($item);?>" alt="">
                                </div>
                                <?php } ?>
                            </div>
                        <?php } else if(!empty($row['pro_image'])){ ?>
                            <div class="featuredImage">
                                <img src="./assets/uploads/products/<?php echo $row['pro_image'];?>" alt="">
                            </div>
                        <?php } else{ ?>
                            <div class="featuredImage">
                                <img src="./assets/images/placeholder.png" alt="">
                            </div>
                        <?php } ?>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="inner">
                        <h4 class="pro_name">
                            <?php echo $row['pro_name'];?>
                        </h4>
                        <p>
                            $ <?php echo $row['pro_r_price'];?>
                        </p>
                        <div class="pro_desc">
                            <?php echo $row['pro_desc'];?>
                        </div>
                        
                        <div class="buyNow">
                            <a href="#">Add to Cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php /*} else{
//     echo "not found";
// } */
?>




<?php
include 'inc/footer.php';
?>