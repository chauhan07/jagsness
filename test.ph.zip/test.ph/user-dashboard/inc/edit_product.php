<?php 
$pro_id = $_GET['id'];
$sql = "SELECT * FROM ap_products_data where id = '$pro_id'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // echo "<pre>";
    // print_r($row);
    // echo "</pre>";
} else {
    $product_msg = "Product Not Found";
    $className = 'alert-danger';
}



if(isset($_POST['submit'])) {
    $product_name = $_POST['product_name'];
    $product_r_name = $_POST['product_r_name'];
    $product_s_name = $_POST['product_s_name'];
    $product_sku = $_POST['product_sku'];
    $product_count = $_POST['product_count'];
    $product_description = $_POST['product_description'];
    $user_id = $ap_user_data['id'];

    if (isset($_FILES['pro_image']) && !empty($_FILES['pro_image']['name'])) {
        $file = $_FILES['pro_image'];
        // Get the file name
        $proImageName = 'profile-'.rand().'-'.$file['name'];
        // Get the file tmp name
        $tmpname = $file['tmp_name'];
        // Move the uploaded file to a new location
        move_uploaded_file($tmpname, "../assets/uploads/products/" . $proImageName);
    } else{
        $proImageName = $row['pro_image'];
    }

    // echo "<pre>";
    // print_r($_FILES['pro_gallery']);
    // // $string = implode(', ', $_FILES['pro_gallery']);
    // // echo $string;
    // echo "</pre>";

    $gallerImagesNames = [];
    $i = 0;

    if (isset($_FILES['pro_gallery']) && !empty($_FILES['pro_gallery']['name'][$i])) {
        $file = $_FILES['pro_gallery'];
        foreach ($file['name'] as $item) {
            $proGalleryImageName = 'products-'.rand().'-'.$item;
            array_push($gallerImagesNames, $proGalleryImageName);
            $tmpname = $file['tmp_name'][$i];
            //print_r($tmpname);
            move_uploaded_file($tmpname, "../assets/uploads/products-gallery/" . $proGalleryImageName);
            $i++;
        }
        //print_r($gallerImagesNames);
        $galleryNameString = implode(', ', $gallerImagesNames);
    } else{
        $galleryNameString = $row['pro_gallery'];
    }

    $sql = 'UPDATE ap_products_data SET pro_name = "'.$product_name.'" , pro_r_price = "'.$product_r_name.'" , pro_s_price = "'.$product_s_name.'" , pro_sku = "'.$product_sku.'" , pro_count = "'.$product_count.'" , pro_desc = "'.$product_description.'" , pro_image = "'.$proImageName.'" , pro_gallery = "'.$galleryNameString.'" WHERE id="'.$pro_id.'"';

    print_r($sql);

    if ($conn->query($sql) === TRUE) {
        header('Location: ./products?edited');

    } else {
        echo "Error updating record: " . $conn->error;
    }

    
}
?>