<?php 
if(isset($_POST['submit'])) {
    $product_name = $_POST['product_name'];
    $product_r_name = $_POST['product_r_name'];
    $product_s_name = $_POST['product_s_name'];
    $product_sku = $_POST['product_sku'];
    $product_count = $_POST['product_count'];
    $product_description = $_POST['product_description'];
    $user_id = $ap_user_data['id'];

    if (isset($_FILES['pro_image']) && !empty($_FILES['pro_image']['name'])) {
        $file = $_FILES['pro_image'];
        // Get the file name
        $proImageName = 'profile-'.rand().'-'.$file['name'];
        // Get the file tmp name
        $tmpname = $file['tmp_name'];
        // Move the uploaded file to a new location
        move_uploaded_file($tmpname, "../assets/uploads/products/" . $proImageName);
    }

    // echo "<pre>";
    // print_r($_FILES['pro_gallery']);
    // // $string = implode(', ', $_FILES['pro_gallery']);
    // // echo $string;
    // echo "</pre>";

    $gallerImagesNames = [];
    $i = 0;

    if (isset($_FILES['pro_gallery']) && !empty($_FILES['pro_gallery']['name'][$i])) {
        $file = $_FILES['pro_gallery'];
        foreach ($file['name'] as $item) {
            $proGalleryImageName = 'products-'.rand().'-'.$item;
            array_push($gallerImagesNames, $proGalleryImageName);
            $tmpname = $file['tmp_name'][$i];
            //print_r($tmpname);
            move_uploaded_file($tmpname, "../assets/uploads/products-gallery/" . $proGalleryImageName);
            $i++;
        }
    }

    //print_r($gallerImagesNames);
    $galleryNameString = implode(', ', $gallerImagesNames);
    


    // SQL query to insert data
    $sql = "INSERT INTO ap_products_data (pro_name, pro_r_price, pro_s_price, pro_sku, pro_count, pro_desc, user_id, pro_image, pro_gallery) VALUES ('$product_name','$product_r_name','$product_s_name','$product_sku','$product_count','$product_description','$user_id','$proImageName','$galleryNameString')";

    if (mysqli_query($conn, $sql)) {
        $register_msg = "Data inserted successfully";
        $className = 'alert-success';

        //header('Location: ./login.php');
        header('Location: ./products?success');
    } else {
        $register_msg = "Error";
        $className = 'alert-danger';
    }
}
?>