<div class="inner sideBar">
    <div class="userInfo">
        <ul>
            <li>
                <img src="../assets/uploads/<?php echo $ap_user_data['image_path'];?>" alt="">
                <h4>Hi, <?php echo $ap_user_data['first_name']." ".$ap_user_data['lastName']; ?></h4>
            </li>
        </ul>
    </div>
    <div class="menuItems">
        <ul>
            <li>
                <a href="./" class="active">Dashboard</a>
            </li>
            <li>
                <a href="./products">Products</a>
            </li>
            <li>
                <a href="#">Task List</a>
            </li>
            <li>
                <a href="#">Services</a>
            </li>
            <li>
                <a href="#">Notification</a>
            </li>
        </ul>
    </div>
</div>