<?php $page_title = 'Products | PHP';
include '../inc/header.php';
if (isset($_SESSION['logedin_user_email'])) {
?>
<section class="container-fluid user-dashboard">
    <div class="container">
        <div class="row">

            <?php if (isset($_GET['success'])) { ?>
            <div class="col-12">
                <div class="afterSubmitMsg alert alert-success text-center">
                    Your Product is Successfully Added 
                </div>
            </div>
            <?php } else if(isset($_GET['deleted'])){ ?>
            <div class="col-12">
                <div class="afterSubmitMsg alert alert-danger text-center">
                    Your Product is Successfully Deleted 
                </div>
            </div>
            <?php } else if(isset($_GET['edited'])){ ?>
            <div class="col-12">
                <div class="afterSubmitMsg alert alert-info text-center">
                    Your Product is Successfully Edited 
                </div>
            </div>
            <?php } ?>

            <div class="col-md-4 col-lg-3">
                <?php include './inc/sidebar.php'; ?>
            </div>

            <div class="col-md-8 col-lg-9">
                <div class="inner">
                    <div class="profile-card">
                        <h4>
                            Products
                            <a href="./add-product.php">Add Product</a>
                        </h4>

                        <div class="productList">
                            <table id="productListTable">
                                <thead>
                                    <th>
                                        ID
                                    </th>
                                    <th>
                                        Product Name
                                    </th>
                                    <th>
                                        Regular Price
                                    </th>
                                    <th>
                                        Sale Price
                                    </th>
                                    <th>
                                        SKU
                                    </th>
                                    <th>
                                        Count
                                    </th>
                                    <th class="text-center">
                                        Action
                                    </th>
                                </thead>
                                <tbody>

                                <?php 
                                    $i = 1;
                                    $sql = "SELECT * FROM userdata JOIN ap_products_data ON ap_products_data.user_id = userdata.id ORDER BY ap_products_data.id DESC";   
                                    $result = mysqli_query($conn, $sql);
                                    if (mysqli_num_rows($result) > 0) {
                                        // Output data of each row
                                        while($row = mysqli_fetch_assoc($result)) { ?>
                                            <tr>
                                                <td>
                                                    <?php echo $i++; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['pro_name']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['pro_r_price']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['pro_s_price']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['pro_sku']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['pro_count']; ?>
                                                </td>
                                                <td class="text-center">
                                                    <a href="./edit-product?id=<?php echo $row['id']; ?>" class="btn edit_btn">
                                                        Edit
                                                    </a>
                                                    <a href="./delete-product?id=<?php echo $row['id']; ?>" class="btn delete_btn">
                                                        Delete
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php }
                                    } else {
                                        $register_msg = "No results found";
                                    }                                
                                ?>
                                </tbody>
                            </table>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
} else{
    header('Location: ../login');
}
include '../inc/footer.php';
?>