<?php 
$page_title = 'User Dashboard | PHP';

include '../inc/header.php';
if (isset($_SESSION['logedin_user_email'])) {
?>
<section class="container-fluid user-dashboard">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-lg-3">
                <?php include './inc/sidebar.php'; ?>
            </div>

            <div class="col-md-8 col-lg-9">
                <div class="inner">
                    <div class="profile-card">
                        <h4>
                            Profile Information
                            <a href="./edit.php">Edit Profile</a>
                        </h4>
                        <div class="userInfoTable">
                            <?php if (isset($_GET['success'])) { ?>
                            <div class="afterSubmitMsg alert alert-success text-center alert-success">
                                Your Profile is successfully updated
                            </div>
                            <?php } ?>
                            <div class="repeat">
                                <div class="box">
                                    Name
                                </div>
                                
                                <div class="box">
                                    <?php echo $ap_user_data['first_name'].' '.$ap_user_data['lastName']; ?>
                                </div>
                            </div>
                            <div class="repeat">
                                <div class="box">
                                    Email
                                </div>
                                
                                <div class="box">
                                    <?php echo $ap_user_data['email']?>
                                </div>
                            </div>
                            <div class="repeat">
                                <div class="box">
                                    Phone
                                </div>
                                
                                <div class="box">
                                    <?php echo $ap_user_data['phone']?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
} else{
    header('Location: ../login');
}
include '../inc/footer.php';
?>