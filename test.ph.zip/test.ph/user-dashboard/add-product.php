<?php 
$page_title = 'Add New Product | PHP'; 

include '../inc/header.php';
if (isset($_SESSION['logedin_user_email'])) {
    include './inc/add_product.php';
?>
<section class="container-fluid user-dashboard">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-lg-3">
                <?php include './inc/sidebar.php'; ?>
            </div>

            <div class="col-md-8 col-lg-9">
                <div class="inner">
                    <div class="profile-card">
                        <h4>
                            Add Product
                        </h4>
                        
                        <form action="" method="POST" id="ap_addProduct_form" enctype="multipart/form-data">
                            <div class="productForm">
                                <div class="p_left">
                                    <label>
                                        Product Name
                                        <input type="text" class="ap_input" name="product_name">
                                    </label>
                                    
                                    <div class="row">
                                        <label class="col-12 col-md-6">
                                            Regular Price
                                            <input type="text" class="ap_input" name="product_r_name">
                                        </label>
                                        <label class="col-12 col-md-6">
                                            Sale Price
                                            <input type="text" class="ap_input" name="product_s_name">
                                        </label>
                                    </div>

                                    <div class="row">
                                        <label class="col-12 col-md-6">
                                            SKU
                                            <input type="text" class="ap_input" name="product_sku">
                                        </label>
                                        <label class="col-12 col-md-6">
                                            Stock Count
                                            <input type="text" class="ap_input" name="product_count">
                                        </label>
                                    </div>

                                    <label>
                                        Product Description
                                        <textarea class="ap_input" name="product_description"></textarea>
                                    </label>

                                </div>
                                <div class="p_right">
                                    <label>
                                        Product Image
                                        <input type="file" name="pro_image" id="" class="ap_input">
                                    </label>
                                    
                                    <label>
                                        Gallery
                                        <input type="file" id="" class="ap_input" name="pro_gallery[]" multiple>
                                    </label>
                                    
                                    <label>
                                        <input type="submit" value="Publish" class="publish_btn" name="submit">
                                    </label>
                                    
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
} else{
    header('Location: ../login');
}
include '../inc/footer.php';
?>