<?php 
include '../inc/connection.php';

$pro_id = $_GET['id'];

$sql = 'DELETE FROM ap_products_data WHERE id = '.$pro_id;

if (mysqli_query($conn, $sql)) {
    header('Location: ./products?deleted');
}
mysqli_close($conn);
?>