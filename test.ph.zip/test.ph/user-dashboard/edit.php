<?php $page_title = 'User Dashboard | PHP'; ?>
<?php include '../inc/header.php';
if (isset($_SESSION['logedin_user_email'])) {
    /** Insert into table **/
    include './inc/edit.php';
    // print_r($ap_user_data);
?>
<section class="container-fluid user-dashboard">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-lg-3">
                <?php include './inc/sidebar.php'; ?>
            </div>

            <div class="col-md-8 col-lg-9">
                <div class="inner">
                    <div class="profile-card">
                        <h4>
                            Edit Profile
                        </h4>
                        <div class="userInfoTable form-box">
                            <?php if (isset($register_msg) && isset($className)) { ?>
                            <div class="afterSubmitMsg alert alert-success text-center <?php echo $className; ?>">
                                <?php 
                                    echo $register_msg;
                                ?>
                            </div>
                            <?php } ?>
                            <form class="row" action="" method="POST" id="ap_register_form" enctype="multipart/form-data">
                                <div class="col-12 col-sm-6 mb-3">
                                    <label for="" class="ap_label">
                                        First Name
                                        <input type="text" name="first_name" value="<?php echo $ap_user_data['first_name']; ?>">
                                    </label>
                                </div>
                                <div class="col-12 col-sm-6 mb-3">
                                    <label for="" class="ap_label">
                                        Last Name
                                        <input type="text" name="last_name" value="<?php echo $ap_user_data['lastName']; ?>">
                                    </label>
                                </div>
                                <div class="col-12 col-sm-6 mb-3">
                                    <label for="" class="ap_label">
                                        Email Name
                                        <input type="email" name="email" value="<?php echo $ap_user_data['email']; ?>">
                                    </label>
                                </div>
                                <div class="col-12 col-sm-6 mb-3">
                                    <label for="" class="ap_label">
                                        Phone Name
                                        <input type="tel" name="phone" value="<?php echo $ap_user_data['phone']; ?>">
                                    </label>
                                </div>
                                <div class="col-12 col-sm-12 mb-3">
                                    <label for="" class="ap_label">
                                        Upload Image
                                        <input type="file" name="user_image" value="">
                                    </label>
                                </div>
                                <div class="col-12 col-sm-12 mb-3">
                                    <input type="submit" class="ap_submitBtn" value="Submit" name="submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
} else{
    header('Location: ../login');
}
include '../inc/footer.php';
?>