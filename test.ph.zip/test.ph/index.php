<?php 
    $page_title = 'Home | PHP';
    include 'inc/header.php'; 
?>


<?php
include 'inc/footer.php';
?>