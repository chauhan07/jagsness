<?php
/**
 * The template for displaying front page
 *
 * (Home Page of Website)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package jagsness-theme
 */
get_header();
?>

<div class="" id="home-page">
	<div class="container">
		<?php if (have_rows('page_sections')): ?>
			<?php while (have_rows('page_sections')): the_row(); ?>
				<?php
					$layout_name = get_row_layout();
					$template_part_path = get_stylesheet_directory() . '/template-parts/scf/' . $layout_name . '.php';

					if (file_exists($template_part_path)) {
						include($template_part_path);
					} else { ?>
						<div class="text-center alert alert-danger my-2">
							<p class="m-0"><?php echo 'Template not found for layout: ' . esc_html($layout_name); ?></p>
						</div>
					<?php }
				?>
			<?php endwhile; ?>
		<?php else: ?>
			<div class="text-center alert alert-danger">
				<p class="m-0"><?php esc_html_e('No sections found. Please add sections in the page editor.', 'jagsness-theme'); ?></p>
			</div>
		<?php endif; ?>
	</div>
</div>
<?php get_footer();?>

